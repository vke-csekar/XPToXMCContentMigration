﻿using CWXPTool.Models;
using System.Collections.Generic;
using System.Linq;

namespace CWXPTool
{
    public static class SitecoreQueryBuilder
    {
        public static GraphQLQuery GetItemQueryByPath(string path, List<string> fieldNames = null)
        {
            if (string.IsNullOrWhiteSpace(path)) return null;

            string fieldQueries = string.Empty;
            
            if (fieldNames != null)
            {
                fieldQueries = string.Join(" ", fieldNames
                .Where(f => !string.IsNullOrWhiteSpace(f))
                .Select(f => $"{f}: field(name: \"{f}\") {{ value }}"));
            }            

            var query = $@"
    query {{
        item(where: {{ database: ""master"", path: ""{path}"" }}) {{
            path: path
            itemId: itemId
            itemName: name
            {fieldQueries}
        }}
    }}";

            return new GraphQLQuery
            {
                Query = query.Replace("\r", "").Replace("\n", " ").Replace("  ", " ").Trim()
            };
        }
    }
}