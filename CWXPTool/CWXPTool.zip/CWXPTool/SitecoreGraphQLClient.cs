﻿using CWXPTool.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CWXPTool
{
    public class SitecoreGraphQLClient
    {
        private readonly string _authoringUrl;
        private readonly HttpClient _httpClient;
        private readonly string _endpoint;

        public SitecoreGraphQLClient()
        {
            _authoringUrl = Constants.AuthoringUrl?.TrimEnd('/');
            _httpClient = new HttpClient();
            _endpoint = $"{_authoringUrl}/sitecore/api/authoring/graphql/v1";
        }

        public async Task<List<CreatedItem>> CreateBulkItemsBatchedAsync(
        List<SitecoreCreateItemInput> items, string accessToken, int batchSize = 50)
        {
            var createdItems = new List<CreatedItem>();

            for (int i = 0; i < items.Count; i += batchSize)
            {
                var batch = items.Skip(i).Take(batchSize).ToList();

                var mutation = SitecoreMutationBuilder.CreateBulkItems(batch);
                var jsonBody = JsonConvert.SerializeObject(mutation);

                var request = new HttpRequestMessage(HttpMethod.Post, _endpoint);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                request.Content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                var content = await response.Content.ReadAsStringAsync();
                if (!response.IsSuccessStatusCode)
                    throw new Exception($"Create failed: {response.StatusCode} - {content}");

                var data = JObject.Parse(content)?["data"];
                if (data == null || data.Type != JTokenType.Object) continue;

                foreach (var prop in data.Children<JProperty>())
                {
                    var item = prop.Value["item"];
                    if (item != null)
                    {
                        createdItems.Add(new CreatedItem
                        {
                            ItemId = item.Value<string>("itemId"),
                            Name = item.Value<string>("name"),
                            Path = item.Value<string>("path"),
                            Language = item["language"]?.Value<string>("name"),
                            Fields = item["fields"]?["nodes"]
                                ?.Select(f => new FieldValue
                                {
                                    Name = f.Value<string>("name"),
                                    Value = f["value"]
                                }).ToList()
                        });
                    }
                }
            }

            return createdItems;
        }

        public async Task<bool> UpdateBulkItemsBatchedAsync(
    List<SitecoreUpdateItemInput> items,
    string accessToken,
    int batchSize = 50)
        {
            var updatedItems = new List<SitecoreUpdatedItem>();

            try
            {
                for (int i = 0; i < items.Count; i += batchSize)
                {
                    var batch = items.Skip(i).Take(batchSize).ToList();
                    var mutation = SitecoreMutationBuilder.UpdateBulkItems(batch);
                    var jsonBody = JsonConvert.SerializeObject(mutation);

                    var request = new HttpRequestMessage(HttpMethod.Post, _endpoint);
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                    request.Content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                    var response = await _httpClient.SendAsync(request);
                    var responseContent = await response.Content.ReadAsStringAsync();

                    if (!response.IsSuccessStatusCode)
                    {
                        Sitecore.Diagnostics.Log.Error($"Failed to update items: {response.StatusCode} - {responseContent}", this);
                        return false;
                    }

                    var json = JObject.Parse(responseContent);

                    if (json["errors"] != null)
                    {
                        Sitecore.Diagnostics.Log.Error("GraphQL Errors: " + json["errors"], this);
                    }

                    var data = json["data"];
                    if (data != null)
                    {
                        foreach (var prop in data.Children<JProperty>())
                        {
                            var item = prop.Value["item"];
                            if (item != null)
                            {
                                var updatedItem = new SitecoreUpdatedItem
                                {
                                    ItemId = item.Value<string>("itemId"),
                                    Name = item.Value<string>("name"),
                                    Path = item.Value<string>("path"),
                                    Language = item["language"]?.Value<string>("name")
                                };
                                updatedItems.Add(updatedItem);

                                Sitecore.Diagnostics.Log.Info($"[GraphQLApiClient] [UPDATE] Item Updated: {updatedItem.Path}", this);
                            }
                        }
                    }



                    Sitecore.Diagnostics.Log.Info($"[GraphQLApiClient] [UPDATE] Items Updated: {updatedItems.Count}", this);
                }

                return true;
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error("Error performing bulk update: " + ex.Message, ex, this);
                return false;
            }
        }


        public async Task<SitecoreItem> QuerySingleItemAsync(string accessToken, string path)
        {
            var query = SitecoreQueryBuilder.GetItemQueryByPath(path);

            var jsonContent = new StringContent(
                Newtonsoft.Json.JsonConvert.SerializeObject(query),
                Encoding.UTF8,
                "application/json");

            try
            {
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await _httpClient.PostAsync(_endpoint, jsonContent);

                if (!response.IsSuccessStatusCode)
                {
                    var errMsg = await response.Content.ReadAsStringAsync();
                    throw new Exception($"GraphQL query failed: {response.StatusCode} - {errMsg}");
                }

                var responseString = await response.Content.ReadAsStringAsync();
                var json = JObject.Parse(responseString);

                if (json["errors"] != null)
                {
                    Console.WriteLine("GraphQL Errors: " + json["errors"]);
                    return null;
                }

                var item = json["data"]?["item"];
                if (item == null)
                    return null;

                return new SitecoreItem
                {
                    ItemId = item.Value<string>("itemId"),
                    Path = item.Value<string>("path"),
                    Name = item.Value<string>("itemName")
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error querying single item: " + ex.Message);
                return null;
            }
        }
    }
}