﻿namespace CWXPTool
{
    public static class Constants
    {
        public const string AuthoringUrl = "https://xmc-childrensho3e59-cw60b4-prod2126.sitecorecloud.io/";
        public const string AuthUrl = "https://auth.sitecorecloud.io/oauth/token";
        public const string Audience = "https://api.sitecorecloud.io";
        public const string Client_ID = "9sDljVEboLPxzMbQpB9euHHtPgNPy4fr";
        public const string Client_Secret = "Nz6HL3keTQDresoTbqJgyPMv0ljQzgbtkIofuaAllCKjNiXl20m1ogimWtrFgZll";
    }
}